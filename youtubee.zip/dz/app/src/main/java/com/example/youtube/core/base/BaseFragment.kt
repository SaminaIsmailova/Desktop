package com.example.youtube.core.base

class BaseFragment {
}