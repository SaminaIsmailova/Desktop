package com.example.kingsmen.data.model

class ModelMasters : ArrayList<ModelMastersItem>()