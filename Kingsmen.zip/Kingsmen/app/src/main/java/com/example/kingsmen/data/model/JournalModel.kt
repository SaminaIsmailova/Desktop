package com.example.kingsmen.data.model

class JournalModel : ArrayList<JournalModelItem>()