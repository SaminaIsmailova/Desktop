package com.example.kingsmen.data.model

class ModelBarberShop : ArrayList<ModelBarberShopItem>()