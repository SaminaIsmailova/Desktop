package com.example.kingsmen.data.model

data class JournalModelItem(
    val id: Int,
    val source_img: String,
    val text: String,
    val title: String
)