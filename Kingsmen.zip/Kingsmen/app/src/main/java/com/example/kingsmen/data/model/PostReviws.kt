package com.example.kingsmen.data.model


data class PostReviws(
    val client:Int,
    val master:Int,
    val rate:Int,
    val text:String,
    val date_time:String
)

