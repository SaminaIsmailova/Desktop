package com.example.kingsmen.data.model

class ModelPortfolio : ArrayList<ModelPortfolioItem>()