package com.example.kingsmen.data.model

class ProductModel : ArrayList<ProductModelItem>()