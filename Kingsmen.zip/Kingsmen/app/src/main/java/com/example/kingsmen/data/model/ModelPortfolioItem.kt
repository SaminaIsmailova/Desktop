package com.example.kingsmen.data.model

data class ModelPortfolioItem(
    val id: Int,
    val master: Int,
    val source_img: String
)