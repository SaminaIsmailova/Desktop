package com.example.rick_and_morty.util

class Constants {
    companion object {
        const val QUERY_PAGE_SIZE = 20
        const val BASE_URL = "https://rickandmortyapi.com/api/"
    }
}