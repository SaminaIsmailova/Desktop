package com.example.rick_and_morty.domain.models


data class Characters(
    val info: Info?,
    val results: List<Character>?
)