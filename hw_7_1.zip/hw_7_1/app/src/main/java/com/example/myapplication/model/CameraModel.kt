package com.example.myapplication.model

data class CameraModel(
    val name:String,
    val img:String,
)
