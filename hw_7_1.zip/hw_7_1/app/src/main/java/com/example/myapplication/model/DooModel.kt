package com.example.myapplication.model

data class DooModel(
    var img:String,
    var name:String,
)